library(testthat)
library(glmLogistic)

test_check("glmLogistic")
